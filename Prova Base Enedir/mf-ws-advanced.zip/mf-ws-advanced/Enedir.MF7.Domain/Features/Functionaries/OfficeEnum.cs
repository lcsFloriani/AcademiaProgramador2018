﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enedir.MF7.Domain.Features.Functionaries
{
    public enum OfficeEnum
    {
        Desenvolvedor,
        Tester,
        Analista,
        Arquiteto,
        GP
    }
}
