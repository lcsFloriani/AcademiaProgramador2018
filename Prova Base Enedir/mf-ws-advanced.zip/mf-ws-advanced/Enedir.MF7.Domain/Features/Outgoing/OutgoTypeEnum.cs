﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enedir.MF7.Domain.Features.Outgoing
{
    public enum OutgoTypeEnum
    {
        Infraestrutura,
        Viagem,
        Alimentacao
    }
}
